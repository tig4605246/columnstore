# MariaDB Columnstore Tools Alias Commands
#
alias mcsimport=/usr/local/mariadb/columnstore/tools/mcsimport/mcsimport
